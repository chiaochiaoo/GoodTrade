

1.UI part

  Trade Option -> USE MOVING AVERAGE X as the stop eval.


Scanner part, oh many thigns.